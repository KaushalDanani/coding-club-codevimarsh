// import icon from "/public/images/Potd.png";

const RecentTasksCardsInfo = [

    {
        id : 1,
        heading:"Problem of The day",
        subheading:"Checkout Today's Problem",
        button:"Let's Go",
        icon:"images/Potd.png"
    },
    {
        id:2,
        heading:"Weekly Contest",
        subheading:"Starts in 1d 12h",
        button:"Checkout",
        icon:"images/Potd.png"
    },
    {
        id:3,
        heading:"Monthly Contest",
        subheading:"Starts in 24d 6h",
        button:"Checkout",
        icon:"images/Potd.png"
    }


]

export default RecentTasksCardsInfo;