// import bulb from "../images/Potd.png";
// import NewsBanner from "../images/NewsBanner.jpg"
// import bell from "../images/bell.webp"
// import react from "../images/logo192.png"

const NewsContentInfo = [

    {
        id : 1,
        title : "News1",
        info : "1 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : "/images/logo192.png"
    },
    {
        id : 2,
        title : "News2",
        info : "2 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : "/images/logo192.png"
    },
    {
        id : 3,
        title : "News3",
        info : "3 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam labore laborum amet veniam fugiat, necessitatibus dolor omnis excepturi. Deserunt, consequuntur?",
        by : "by: Lorem, ipsum.",
        url : "/images/logo192.png"
    },
    {
        id : 4,
        title : "News4",
        info : "4 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : "/images/logo192.png"
    },
    {
        id : 5,
        title : "News5",
        info : "5 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : ""
    },
    {
        id : 6,
        title : "News6",
        info : "6 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : ""
    },
    {
        id : 7,
        title : "News7",
        info : "7 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : ""
    },
    {
        id : 8,
        title : "News8",
        info : "8 News Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : "/images/logo192.png"
    },
    {
        id : 9,
        title : "News9",
        info : "9 News Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : "/images/logo192.png"
    },
    {
        id : 10,
        title : "News10",
        info : "10 News Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates aut minus necessitatibus ullam corporis, atque delectus in nobis quo nesciunt doloremque minima. Numquam sequi est quae odit facere nihil aperiam necessitatibus doloremque alias beatae ut voluptas expedita asperiores, eveniet hic? Corrupti velit beatae quae minima dolorum culpa quia cumque enim?",
        by : "by: Lorem, ipsum.",
        url : "/images/logo192.png"
    }
    
]

export default NewsContentInfo