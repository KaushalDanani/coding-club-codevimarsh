const ResourcesNotesInfo = [
    {
        id:1,
        title:"Previous Years' Question Papers",
        link:"#" 
    },
    {
        id:2,
        title:"Cheat Sheet for Formulas",
        link:"#" 
    },
    {
        id:3,
        title:"Note3 erth4yjku",
        link:"#" 
    },
    {
        id:4,
        title:"Note4",
        link:"#" 
    },
    {
        id:5,
        title: "Lorem ipsum dolor sit amet",
        link:"#" 
    },
    {
        id:6,
        title: "Lorem, ipsum dolor.",
        link:"#" 
    },
    {
        id:6,
        title:"Note4",
        link:"#" 
    },
    {
        id:6,
        title: "Lorem ipsum dolor sit.",
        link:"#" 
    },
]

export default ResourcesNotesInfo