// import "/images/profile.jpeg" from "../images/profile.jpeg"

const ResourcesBookInfo = [
    {
        id : 1,
        url : "/images/profile.jpeg",
        title : "Book1",
        edition :"5th Edition",
        author : "ABC"
    },
    {
        id : 2,
        url : "/images/profile.jpeg",
        title : "Book2",
        edition : "Small Description",
        author : "ABC"
    },
    {
        id : 3,
        url : "/images/profile.jpeg",
        title : "Book3",
        edition : "Small Description",
        author : "ABC"
    },
    {
        id : 4,
        url : "/images/profile.jpeg",
        title : "Book4",
        edition : "Small Description",
        author : "ABC"
    },
    {
        id : 5,
        url : "/images/profile.jpeg",
        title : "Book5",
        edition : "Small Description",
        author : "ABC"
    },
    {
        id : 6,
        url : "/images/profile.jpeg",
        title : "Book6",
        edition : "Small Description",
        author : "ABC"
    },
]

export default ResourcesBookInfo