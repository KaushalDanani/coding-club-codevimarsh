const ResourcesVideoInfo = [
    {
        id : 1,
        thumbnail : "https://www.youtube.com/embed/irqbmMNs2Bo?si=2trpYqoj_7WHioaS",
        title : "Introduction to C Language - One shot video for beginners",
        channel : "Apna College",
        source : "Youtube"
    },
    {
        id : 2,
        thumbnail : "https://www.youtube.com/embed/irqbmMNs2Bo?si=2trpYqoj_7WHioaS",
        title : "Video1",
        channel : "Channel1",
        source : "Youtube"
    },
    {
        id : 3,
        thumbnail : "https://www.youtube.com/embed/irqbmMNs2Bo?si=2trpYqoj_7WHioaS",
        title : "Video1",
        channel : "Channel1",
        source : "Youtube"
    },
    {
        id : 4,
        thumbnail : "https://www.youtube.com/embed/irqbmMNs2Bo?si=2trpYqoj_7WHioaS",
        title : "Video1",
        channel : "Channel1",
        source : "Youtube"
    },
]

export default ResourcesVideoInfo;