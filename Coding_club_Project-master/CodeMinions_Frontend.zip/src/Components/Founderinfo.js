const founderinfo = [
    {
        id : 1,
        name : "Soham Zadafiya",
        post : "Founder",
        image : "https://img.freepik.com/premium-photo/teacher-man-avatar-icon-illustration-vector-style_131965-961.jpg?size=626&ext=jpg&ga=GA1.1.1360090374.1689347540&semt=ais"
    },
    {
        id : 2,
        name : "Jay Fanse",
        post : "Founder",
        // image : "https://img.freepik.com/premium-photo/blue-software-code-3d-icon-isolated-white-background-with-website-coding-technology-sign-programming-developer-ui-writing-application-symbol-design-java-program-script-html-data-development_79161-2438.jpg?size=626&ext=jpg&ga=GA1.1.1360090374.1689347540&semt=ais"
        image : "https://img.freepik.com/premium-photo/teacher-man-avatar-icon-illustration-vector-style_131965-961.jpg?size=626&ext=jpg&ga=GA1.1.1360090374.1689347540&semt=ais"
    },
    {
        id : 3,
        name : "Kaushal Danani",
        post : "Founder",
        // image : "https://img.freepik.com/premium-photo/blue-software-code-3d-icon-isolated-white-background-with-website-coding-technology-sign-programming-developer-ui-writing-application-symbol-design-java-program-script-html-data-development_79161-2438.jpg?size=626&ext=jpg&ga=GA1.1.1360090374.1689347540&semt=ais"
        image : "https://img.freepik.com/premium-photo/teacher-man-avatar-icon-illustration-vector-style_131965-961.jpg?size=626&ext=jpg&ga=GA1.1.1360090374.1689347540&semt=ais"
    },
    {
        id : 4,
        name : "Jay Prajapati",
        post : "Founder",
        // image : "https://img.freepik.com/premium-photo/blue-software-code-3d-icon-isolated-white-background-with-website-coding-technology-sign-programming-developer-ui-writing-application-symbol-design-java-program-script-html-data-development_79161-2438.jpg?size=626&ext=jpg&ga=GA1.1.1360090374.1689347540&semt=ais"
        image : "https://img.freepik.com/premium-photo/teacher-man-avatar-icon-illustration-vector-style_131965-961.jpg?size=626&ext=jpg&ga=GA1.1.1360090374.1689347540&semt=ais"
    }
];

export default founderinfo;