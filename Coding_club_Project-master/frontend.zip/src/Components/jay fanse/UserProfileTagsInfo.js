const tagCollection = [
    {
        id : 1,
        name : "C",
        use : false
    },
    {
        id : 2,
        name : "C++",
        use : false
    },
    {
        id : 3,
        name : "JAVA",
        use : false
    },
    {
        id : 4,
        name : "DSA",
        use : false
    },
    {
        id : 5,
        name : "DBMS",
        use : false
    },
    {
        id : 6,
        name : "ReactJS",
        use : false
    },
    {
        id : 7,
        name : "NodeJS",
        use : false
    },
    {
        id : 8,
        name : "Problem solving",
        use : false
    }
];

export default tagCollection;