import React from 'react'

    const UserProfileInfo = {
        fname:  "Jay",
        lname: "Fanse",
        about : "Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, corporis kill Tags here Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime rerum, commodi eos veritatis, deserunt error odio similique sunt ex dolor veniam. Suscipit aliquid delectus tempore quos hic, incidunt ut et inventore libero reiciendis ab facilis eveniet mollitia saepe deserunt ipsum perspiciatis corporis laboriosam labore voluptatibus eos autem dolor natus. Fuga?",
        linkedIn : "https//localhost:3000",
        programme: 2,
        dept: 0,
        year: 2,
        username: "jayfanse29",
        email: "jayf29112003@gmail.com",
        pass: "abc123"
    }


export default UserProfileInfo;