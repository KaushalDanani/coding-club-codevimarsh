import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import "./DiscussionCard.css"
import "./Forums.css"

export default function Discussion_block(props) {
    function getTag(tag) {
        return (
            <div className="q_tag">{tag}</div>
        )
    }

    const [tag, setTags] = useState([]);

    useEffect(() => {
        if (props.tags) {
            setTags(props.tags);
        }
    }, [props.tags])

    const [qDate, setQDate] = useState("");

    useEffect(() => {
        if (props.date) {
            var dt = new Date(props.date);
            setQDate(dt.getDate() + "-" + (dt.getMonth()+1) + "-" + dt.getFullYear());
        }
    }, [props.date])
    const location = useLocation();
    const userID = sessionStorage.getItem('userID')

    return (
        // <div id='discussion_block'>
        //     <a href={`discussion/question?q_id=${props.q_id}`}>
        //         <div className='asker' id={props._id}>
        //             <a href={`profile?visitID=${props.asker_id}`}><div id='pfp_div'><img src={`data:Image/jpeg;base64,${props.pfp}`} alt="" id='pfpic' /></div></a>
        //             <div id='asker_id'><a href={`profile?visitID=${props.asker_id}`}>{props.asker_username}</a></div>
        //         </div>
        //         <div id='ques'>
        //             {props.question}
        //         </div>
        //         <div id="ques_tags">
        //             {props.tags.map(getTag)}
        //             <div id='q_date'>{props.date}</div>
        //         </div>
        //     </a>
        // </div>

        <div className='discussion_c_card'>
            <div className='avtarDisc'> <a href={`profile?visitID=${props.asker_id}`}> <img src={`data:Image/jpeg;base64,${props.pfp}`} /> </a> </div>
            <a href={`discussion/question?q_id=${props.q_id}`}>
                <div className='innercontentDisc'>
                    <div className='asker' id={props._id}>
                        <div id='asker_id'><a href={`profile?visitID=${props.asker_id}`}>{props.asker_username}</a></div>
                    </div>
                    <div id='ques'>
                        {props.question}
                    </div>
                    <div id="ques_tags">
                        {console.log(tag)}
                        {tag.map(getTag)}
                        <div id='q_date'>{qDate}</div>
                    </div>
                </div>
            </a>
        </div>
    )
}
