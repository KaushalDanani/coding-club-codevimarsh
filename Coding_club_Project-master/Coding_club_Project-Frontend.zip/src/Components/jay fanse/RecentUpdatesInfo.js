// import icon from "../public/images/Potd.png"
// import ai from "../../images/AI.png"

const RecentUpdatesCardsInfo = [
    
    {
        id:1,
        heading:"Domination of Artificial Intelligence by 2030",
        subheading:"Checkout Latest Blog",
        button:"Checkout",
        icon:"images/AI.png"
    },
    {
        id:2,
        heading:"Blog Heading",
        subheading:"Blog Info",
        button:"Checkout",
        icon:"images/Potd.png"
    },
    {
        id:3,
        heading:"Blog Heading",
        subheading:"Blog Info",
        button:"Checkout",
        icon:"images/Potd.png"
    }
]

export default RecentUpdatesCardsInfo;